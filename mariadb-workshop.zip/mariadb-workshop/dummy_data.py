#!/usr/bin/python3
# coding: utf-8
# https://faker.readthedocs.io/en/stable/index.html

from faker import Faker
import mysql.connector

fake = Faker('fr_FR')

cnx = mysql.connector.connect(user='sample', password='sample_password', host='127.0.0.1', database='sampledb')
cursor = cnx.cursor()

add_user = ("INSERT INTO users "
            "(name, email, address, phone, credit_card) "
            "VALUES (%(name)s, %(email)s, %(address)s, %(phone)s, %(credit_card)s)")

for i in range(1000):
    data_user = {
        'name': fake.name(),
        'email': fake.email(),
        'address': fake.address().replace("\n", " - "),
        'phone': fake.phone_number(),
        'credit_card': fake.credit_card_number(card_type=None)
    }

    cursor.execute(add_user, data_user)

    cnx.commit()

cursor.close()
cnx.close()
