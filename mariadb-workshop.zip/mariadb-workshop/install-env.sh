#!/bin/bash

###
# TITLE  = Database Security Prerequisites Setup
# AUTHOR = Obejero, Cedric - <cedric.obejero@tanooki.fr>
# DATE   = May 5th, 2022
# COURSE = SYSTEM SECURITY
# 
# Copyright - 2022 - All right reserved - TANOOKI S.A.S.U.
###

BASENAME=$(basename $0)
AUTHOR="Cedric OBEJERO <cedric.obejero@tanooki.fr>"
RELEASE="V2R0"
REL_DATE="May 5th, 2022"

RST='\033[0;0m'
BOLD='\033[0;1m'
RED='\033[0;31m'
GRN='\033[0;32m'
YEL='\033[0;33m'

TNK_CONFIG="/etc/tnk/tnk_config"
TNK_DIR="/etc/tnk/"

SETUP=0
USAGE=0
VERSION=0

while [[ $# > 0 ]]; do
	ARG="$1"
	case $ARG in
	-s|--setup)
		SETUP=1
		;;
	-h|--help)
		USAGE=1
		;;
	-v|--version)
		VERSION=1
		;;
	*)
		printf "[${RED}ERROR${RST}] - Unknonw argument, aborting\n\n"
		exit 128
		;;
	esac
	shift
done

usage() {
	printf "${BOLD}NAME${RST}\n"
	printf "	$BASENAME\n\n"
	printf "${BOLD}SYNOPSIS${RST}\n"
	printf "	$BASENAME [OPTIONS]\n\n"
	printf "${BOLD}DESCRIPTION${RST}\n"
	printf "	Setting up environment to pratice Database Security Course\n"
	printf "	Guidelines and Course provided by Tanooki - https://www.tanooki.fr\n\n"
	printf "	Mandatory arguments are as follow.\n\n"
	printf "	-s, --setup\n"
	printf "		WARNING - Must be executed with ROOT privileged\n"
	printf "		Install Docker Engine and Compose and launch training MariaDB MaxScale container\n\n"
	printf " 	-h, --help\n"
	printf "		Display current help information\n\n"
	printf "	-v, --version\n"
	printf " 		Display command release informations\n\n"
}

show_version() {
	printf "${BOLD}NAME${RST}    $BASENAME\n"
	printf "${BOLD}AUTHOR${RST}  $AUTHOR\n"
	printf "${BOLD}RELEASE${RST} $RELEASE\n"
	printf "${BOLD}DATE${RST}    $REL_DATE\n"
}

setup() {
	if [ "$(id -u)" != "0" ]; then
		printf "[${YEL}WARNING${RST}] - Checking host requires ROOT access\n"
		exit 2
	fi
	
	printf "[${GRN}INFO${RST}] - Start environment setup. Please wait ...\n\n"

	printf "[${GRN}INFO${RST}] - Uninstall old versions of Docker components\n"
	apt-get autoremove docker docker-engine docker.io containerd runc

	printf "[${GRN}INFO${RST}] - Set up Docker repository\n"
	apt-get update
	apt-get install ca-certificates curl gnupg lsb-release
	curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
	echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

	printf "[${GRN}INFO${RST}] - Install Docker Engine and Docker Compose\n"
	apt-get update
	apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin docker-compose

	docker run hello-world > /dev/null
	if [ $? != 0 ]; then
		printf "\n\n[${RED}ERROR${RST}] - Docker setup failed - Please check /var/log/dmesg for more information\n\n"
		exit 128
	else 
		printf "\n\n[${GRN}INFO${RST}] - Docker successfully set up\n"
	fi

	which docker-compose > /dev/null
	if [ $? != 0 ]; then
		printf "\n\n[${RED}ERROR${RST}] - Docker setup failed - Please check /var/log/dmesg for more information\n\n"
		exit 128
	else 
		printf "\n\n[${GRN}INFO${RST}] - Docker successfully set up\n"
	fi

	printf "[${GRN}INFO${RST}] - Starting MariaDB Container to work with\n"
	docker compose up -d

	printf "[${GRN}INFO${RST}] - Set up Python Tools for automation\n"	
	apt-get install -y pip pipenv

	printf "[${GRN}INFO${RST}] - Creating sample database, table and dummy data\n"
	apt-get install -y mysql-client
	mysql -u root -h 127.0.0.1 -ppassword < create-sampledb.sql
	if [ $? != 0 ]; then
		printf "\n\n[${RED}ERROR${RST}] - Fail to create Database - Please check /var/log/dmesg for more information\n\n"
		exit 128
	else 
		printf "\n\n[${GRN}INFO${RST}] - Database System is ready to complete\n"
	fi

	pipenv run pip install Faker
	pipenv run pip install mysql-connector-python
	pipenv run python3 dummy_data.py
	if [ $? != 0 ]; then
		printf "\n\n[${RED}ERROR${RST}] - Enable to add data - Please check /var/log/dmesg for more information\n\n"
		exit 128
	else 
		printf "\n\n[${GRN}INFO${RST}] - Database is loaded with data and ready to use\n"
	fi

	printf "\n\n[${GRN}INFO${RST}] - MariaDB Workshop Setup is COMPLETE\n\n"

}

## SCRIPT CORE
##
if [[ $USAGE = 1 ]]; then
	usage
	exit 1
elif [[ $VERSION = 1 ]]; then
	show_version
	exit 1
elif [[ $SETUP = 1 ]]; then
	setup
	exit 1
else 
	printf "[${RED}ERROR${RST}] - Invalid operation requested\n\n"
	usage
	exit 128
fi

### EOF ###
